
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'samueltefera',
  applicationName: 'serverless-todo-app',
  appUid: 'w5jRZCh77mj0lq5kDx',
  orgUid: 'dda099e8-ce46-45df-8d9d-5071b43bfb03',
  deploymentUid: '996c38e2-a087-4b1a-b700-e86e06a6303d',
  serviceName: 'serverless-todo-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-todo-app-dev-CreateTodo', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/createTodo.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}